# encoding=utf-8
print u'我是p1'
b = u'我是p1中的变量'
# encoding=utf-8
print u'我是p2'
a = u'我是p2中的变量'